module.exports = {
    // --- TELEGRAM SETTINGS ---
    botToken: "8292296245:AAFJL512du-ym9O6AjJKCxaJnE2pQSx77Q",
    ownerId: 8459142797,
    ownerName: "Ralzz",
    ownerWa: "Tidak ada",
    ownerUser: "@ralzbakekok",
    grubName: "ralzzpublik", // isi tanpa @ dan https://t.me/
    channelName: "ralzzofc", // isi tanpa @ 
    botName: "𝗥𝗮𝗹𝘇𝘇 𝗢𝗿𝗱𝗲𝗿 𝗩𝟴",
    startPhoto: "https://files.catbox.moe/fdm5e5.jpg",
    startAudio: "https://files.catbox.moe/1u42o5.mp3",
    startAudioCaption: "Welcome To Ralzz Order V7!!",
    testimoniChannel: "@ralzzofc",
    
    // --- Nokos Setting ( Rumah Otp )
    RUMAHOTP: "otp_OAhKwxoYqtCyRCS",
    UNTUNG_NOKOS: 500,
    UNTUNG_DEPOSIT: 500,
    ppthumb: "https://files.catbox.moe/fdm5e5.jpg",
    
    // --- Suntik Sosmed Setting ( FayuPedia )
    smm: {
        apiId: '64350', 
        apiKey: 'ahzynn-xrofzw-boalox-jtinh-irruw3', 
        baseUrl: 'https://fayupedia.id/api' 
    },

    // --- PAYMENT ORKUT ---
    payment: {
        apikey: "jekk", // jan ganti nnti eror
        username: "tokofaa",
        token: "2420562:SUVDf2e9Cv5AoMFyin1HGcdYqPwJasL"
    },

    // --- PAYMENT ATLANTIC ---
    ApikeyAtlantic: "ap1HhR2fPeQ88lvgPKrsfitABlERz7V0SyRdRKVEmTA6PUlNoluso7JBtaVHkfeCtyzksQmz7t4wRNbenBfXlNZiPYbllkX5fEA",
    wd_balance: {
        bank_code: "DANA", // DANA, BCA, BRI, dll
        destination_number: "081259435726",
        destination_name: "SUHARIADI",
    },
    
    // --- Qris Manual Setting ---
    manualQrisPhoto: "https://files.catbox.moe/orwja1.png",
    
    // --- Vps Setting ---
    ApiDO1: "digitalocean_api_key_lu", // ganti api do lu
    hargaVPS: {
       low: {
        "2c2": 20000,
        "4c2": 35000,
        "8c4": 60000,
        "16c4": 90000,
        "16c8": 120000
      },
       medium: {
        "2c2": 25000,
        "4c2": 40000,
        "8c4": 65000,
        "16c4": 95000,
        "16c8": 125000
      },
       high: {
        "2c2": 50000,
        "4c2": 75000,
        "8c4": 100000,
        "16c4": 130000,
        "16c8": 150000
    }
  },
    // --- Fix Error Setting
    USER_LIMIT: 3,
    GEMINI_API_KEY: "AIzaSyB47adRUMkO-Yn_MOcOZBDV0PFIpzqKBy4",
    
    // --- PTERODACTYL PANEL ---
    panel: {
        domain: "https://kayyprivate.hostingvvip.my.id",
        apikey: "ptla_qczyKxi0FIT7NtH919ACLHUaTRfbhdyazpMmJcxbrA4",
        nestId: 5,
        eggId: 15,
        locationId: 1,
        startup: "npm start",
        image: "ghcr.io/parkervcp/yolks:nodejs_18"
    },

    // --- HARGA PANEL ---
    hargaAdminPanel: 10000,
    hargaResellerPanel: 5000,
    linkResellerPanel: "https://t.me/ralzzofc",
    hargaPanel: {
        unlimited: 2000,
        perGB: 750,  
    }
};